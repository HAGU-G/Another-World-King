﻿public static class Tags
{
    public static readonly string tower = "Tower";
    public static readonly string unit = "Unit";
}
public enum COMBAT_TYPE
{
    STOP_ON_HAVE_TARGET,
    STOP_ON_ATTACK,
    DONT_STOP
}