using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(InitStats))]
public class UnitStatsDataEditor : Editor
{
    private InitStats stats = null;
    private SerializedProperty attackEnemyOrder = null;

    private void OnEnable()
    {
        stats = target as InitStats;
        attackEnemyOrder = serializedObject.FindProperty("initAttackEnemyOrder");
    }

    public override void OnInspectorGUI()
    {
        serializedObject.Update();
        Undo.RecordObject(stats, "���� ���� ����");

        //ID & State
        stats.id = EditorGUILayout.IntField("ID", stats.id);
        stats.isTower = EditorGUILayout.Toggle("Ÿ��", stats.isTower);

        //ü��
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("ü��");
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.Space(10, false);
        EditorGUILayout.BeginVertical();
        stats.initHP = Mathf.Clamp(EditorGUILayout.IntField("�ִ� ü��", stats.initHP), 0, int.MaxValue);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("���۰� ���", GUILayout.MaxWidth(65));
        stats.useStartHP = EditorGUILayout.Toggle(stats.useStartHP, GUILayout.Width(15));
        if (stats.useStartHP)
            stats.initHPStart = Mathf.Clamp(EditorGUILayout.IntField(stats.initHPStart), 0, stats.initHP);
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndHorizontal();

        if (stats.isTower)
            return;

        //����
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("����");
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.Space(10, false);
        EditorGUILayout.BeginVertical();
        stats.combatType = (COMBAT_TYPE)EditorGUILayout.EnumPopup("���� ���", stats.combatType);
        stats.initAttackDamage = EditorGUILayout.IntField("���ݷ�", stats.initAttackDamage);
        stats.initAttackSpeed = Mathf.Clamp(EditorGUILayout.FloatField("���� �ӵ�", stats.initAttackSpeed), 0f, float.MaxValue);
        stats.initAttackRange = Mathf.Clamp(EditorGUILayout.FloatField("���� ����", stats.initAttackRange), 0f, float.MaxValue);
        stats.initAttackEnemyCount = Mathf.Clamp(EditorGUILayout.IntField("���� ������ ���� ��", stats.initAttackEnemyCount), 1, int.MaxValue);
        stats.initAttackOrder = Mathf.Clamp(EditorGUILayout.IntField("���� ���� ������", stats.initAttackOrder), 1, int.MaxValue);
        EditorGUILayout.PropertyField(attackEnemyOrder, new GUIContent("���� ������ ���� ������", "���� �켱���� ��������"));
        if (attackEnemyOrder.arraySize < stats.initAttackEnemyCount)
            EditorGUILayout.HelpBox("���� ������ '���� ������ ��'�� '���� ��'�̻��̾�� �մϴ�.", MessageType.Warning);
        for (int i = 0; i < attackEnemyOrder.arraySize; i++)
        {
            if (attackEnemyOrder.GetArrayElementAtIndex(i).intValue < 1)
            {
                EditorGUILayout.HelpBox("1 �̻��� int���� �ʿ��մϴ�.", MessageType.Warning);
                break;
            }
        }
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndHorizontal();

        //��
        EditorGUILayout.Space(10);
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("��", GUILayout.Width(15));
        stats.isHealer = EditorGUILayout.Toggle(stats.isHealer, GUILayout.Width(15));
        EditorGUILayout.EndHorizontal();
        if (stats.isHealer)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.Space(10, false);
            EditorGUILayout.BeginVertical();
            stats.initHeal = Mathf.Clamp(EditorGUILayout.IntField("����", stats.initHeal), 0, int.MaxValue);
            EditorGUILayout.EndVertical();
            EditorGUILayout.EndHorizontal();
        }

        //��Ÿ
        EditorGUILayout.Space(10);
        EditorGUILayout.LabelField("��Ÿ");
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.Space(10, false);
        EditorGUILayout.BeginVertical();
        stats.initMoveSpeed = Mathf.Clamp(EditorGUILayout.FloatField("�̵� �ӵ�", stats.initMoveSpeed), 0f, float.MaxValue);
        stats.cost = Mathf.Clamp(EditorGUILayout.IntField("��ȯ ����", stats.cost), 0, int.MaxValue);
        stats.initDropGold = Mathf.Clamp(EditorGUILayout.IntField("óġ ���", stats.initDropGold), 0, int.MaxValue);
        stats.initDropExp = Mathf.Clamp(EditorGUILayout.IntField("óġ ����ġ", stats.initDropExp), 0, int.MaxValue);
        EditorGUILayout.EndVertical();
        EditorGUILayout.EndHorizontal();

        serializedObject.ApplyModifiedProperties();
        PrefabUtility.RecordPrefabInstancePropertyModifications(stats);
        EditorUtility.SetDirty(stats);
    }
}
